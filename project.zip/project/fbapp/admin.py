from django.contrib import admin
from .models import FbModel

admin.site.register(FbModel)
